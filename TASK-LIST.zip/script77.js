const inputbox = document.getElementById("input-id");
const tasksList = document.getElementById("tasks-list");
const btn = document.getElementById("add_task");

btn.addEventListener("click", () =>{
    if (inputbox.value === ''){
        alert("You can't add the empty task")
    }
    else{
        let li = document.createElement("li");
        li.innerHTML = inputbox.value;
        tasksList.appendChild(li);
        let span = document.createElement("span");
        span.innerHTML = "X";
        li.appendChild(span);
        }
        inputbox. value = "";
})
tasksList.addEventListener("click", function(e){
    if(e.target.tagName === "LI"){
        e.target.classList.toggle("task");
    }
    else if (e.target.tagName === "SPAN"){
        e.target.parentElement.remove();
    }
}, false)